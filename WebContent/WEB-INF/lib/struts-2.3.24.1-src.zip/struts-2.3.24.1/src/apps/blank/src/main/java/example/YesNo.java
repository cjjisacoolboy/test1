package example;

public enum YesNo {
    YES, NO
}
